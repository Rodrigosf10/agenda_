<!DOCTYPE html>
<html>
<head>
	<title>Agenda de Contactos WEB</title>
	<link rel="icon" type="image/png" href="librerias/img/Xanna.ico">
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<?php
		require_once "dependencias.php";
	?>

</head>
<body>
	<div class="container">
		<?php  
			require_once "menu.php";
		?>
	</div>
	<div class="container">
		<?php require_once "menu.php"; ?>

		<div class="jumbotron">
			<h1 class="display-4">Mi Agenda de Contactos</h1>
			<div class="row">
				<div class="col-sm-6">
					<div class="card">
						<div class="card-body">
							<img src="librerias/img/Chazz.png" class="img-fluid" alt="Responsive image">
						</div>
					</div>
				</div>
				<div class="col-sm-6">
					<div class="card">
						<div class="card-body">
							<table class="table table-hover">
								<tr>
									<th>
										Agenda Creada
									</th>
								</tr>
								<tr>
									<th>
										Hecho en Sublime Text 3
									</th>
								</tr>
								<tr>
									<th>
										By: Sandoval Flores Rodrigo
									</th>
								</tr>
							</table>
						</div>
					</div>
				</div>
			</div>
			<hr class="my-4">
			<p>
				By: Sandoval Flores Rodrigo
			</p>
		</div>
	</div>
</body>
</html>