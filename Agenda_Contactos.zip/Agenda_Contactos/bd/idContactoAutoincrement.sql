ALTER TABLE `agendafa`.`t_contactos` 
CHANGE COLUMN `id_contacto` `id_contacto` INT(11) NOT NULL AUTO_INCREMENT ;
